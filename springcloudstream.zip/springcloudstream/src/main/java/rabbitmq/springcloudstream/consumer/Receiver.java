package rabbitmq.springcloudstream.consumer;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.SendTo;
import rabbitmq.springcloudstream.entity.MyMessage;
import rabbitmq.springcloudstream.stream.ClientStream;

import java.util.Date;

@EnableBinding(ClientStream.class)
public class Receiver {
    @StreamListener(ClientStream.INPUT)
    @SendTo(ClientStream.OUTPUT)
    public MyMessage receiverMessage(MyMessage myMessage){
        System.out.println("接收到的 MyMessage 消息：" + myMessage);
        myMessage.setContent("这里是消息的内容，对消息进行了处理");
        myMessage.setDate(new Date());
        return myMessage;
    }

    @StreamListener(ClientStream.OUTPUT)
    public void receiverNewMessage(MyMessage myMessage){
        System.out.println("接收到处理过的 MyMessage 消息：" + myMessage);
    }
}
