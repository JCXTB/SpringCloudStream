package rabbitmq.springcloudstream.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import rabbitmq.springcloudstream.entity.MyMessage;
import rabbitmq.springcloudstream.stream.ClientStream;

import java.util.Date;

@RestController
@RequestMapping("/producer")
public class SendController {
    @Autowired
    private ClientStream clientStream;

    @GetMapping("/sendMessage")
    public void sendMessage(){
        MyMessage myMessage = new MyMessage();
        myMessage.setId("测试 ID");
        myMessage.setContent("这里是消息的内容");
        myMessage.setDate(new Date());

        clientStream.input().send(MessageBuilder.withPayload(myMessage).build());
    }
}
