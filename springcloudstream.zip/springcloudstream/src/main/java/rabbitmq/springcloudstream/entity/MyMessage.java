package rabbitmq.springcloudstream.entity;

import lombok.Data;

import java.util.Date;

@Data
public class MyMessage {

    private String id;

    private String content;

    private Date date;
}
